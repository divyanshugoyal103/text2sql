
import React, { useState, useEffect } from 'react';
import { ClipboardIcon, ClipboardCheckIcon, CodeIcon } from './Icons';

interface SqlOutputProps {
  sql: string;
  isLoading: boolean;
  loadingText?: string;
}

export const SqlOutput: React.FC<SqlOutputProps> = ({ sql, isLoading, loadingText }) => {
  const [isCopied, setIsCopied] = useState<boolean>(false);

  useEffect(() => {
    if (isCopied) {
      const timer = setTimeout(() => setIsCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [isCopied]);

  const handleCopy = () => {
    if (sql) {
      navigator.clipboard.writeText(sql);
      setIsCopied(true);
    }
  };

  return (
    <div className="bg-gray-900/80 backdrop-blur-sm border border-gray-700 rounded-2xl shadow-lg">
      <div className="flex justify-between items-center p-4 border-b border-gray-700">
        <h3 className="flex items-center text-lg font-semibold text-white">
            <CodeIcon className="w-6 h-6 mr-3 text-cyan-400"/>
            Generated SQL Query
        </h3>
        <button
          onClick={handleCopy}
          disabled={!sql || isLoading}
          className="flex items-center text-sm bg-gray-700/50 hover:bg-gray-700/90 disabled:opacity-50 text-gray-300 font-medium py-1.5 px-3 rounded-lg transition-colors"
        >
          {isCopied ? (
            <>
              <ClipboardCheckIcon className="w-4 h-4 mr-2 text-green-400" />
              Copied!
            </>
          ) : (
            <>
              <ClipboardIcon className="w-4 h-4 mr-2" />
              Copy
            </>
          )}
        </button>
      </div>
      <div className="p-4">
        <pre className="w-full text-left bg-black p-4 rounded-lg overflow-x-auto">
          <code className="language-sql text-cyan-300 font-mono text-sm whitespace-pre-wrap">
            {isLoading ? (
                <span className="text-gray-400 animate-pulse">{loadingText || 'Generating your SQL query...'}</span>
            ) : (
                sql || <span className="text-gray-500">Your generated SQL will appear here.</span>
            )}
          </code>
        </pre>
      </div>
    </div>
  );
};
