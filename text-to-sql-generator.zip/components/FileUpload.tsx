
import React, { useState, useCallback, useRef } from 'react';
import { UploadCloudIcon, FileIcon, CheckCircleIcon } from './Icons';

interface FileUploadProps {
  onFileChange: (file: File, contentPreview: string, headers: string[]) => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileChange }) => {
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [fileName, setFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((file: File) => {
    if (file) {
      setFileName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = (e.target?.result as string) || '';
        // Provide a preview of the first 1000 characters
        const preview = text.slice(0, 1000);

        // Auto-detect headers from the first line of the file (e.g., CSV)
        const firstLine = text.split('\n')[0] || '';
        const headers = firstLine.split(',')
          .map(h => h.trim().replace(/^"|"$/g, '')) // Trim whitespace and remove surrounding quotes
          .filter(h => h); // Filter out any empty headers that might result from trailing commas

        onFileChange(file, preview, headers);
      };
      reader.readAsText(file);
    }
  }, [onFileChange]);

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };


  return (
    <div>
      <label className="block text-sm font-medium text-gray-300 mb-2">
        Upload a data file (CSV, TXT)
      </label>
      <div
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        onClick={handleClick}
        className={`flex justify-center items-center w-full px-6 py-8 border-2 ${
          isDragging ? 'border-cyan-400 bg-cyan-500/10' : 'border-gray-600 border-dashed'
        } rounded-lg cursor-pointer transition-colors duration-300`}
      >
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          accept=".csv,.txt"
          onChange={handleInputChange}
        />
        {fileName ? (
          <div className="text-center text-green-400">
            <CheckCircleIcon className="w-10 h-10 mx-auto mb-2" />
            <p className="font-semibold">File Uploaded!</p>
            <p className="text-sm text-gray-400 flex items-center justify-center mt-1">
                <FileIcon className="w-4 h-4 mr-2"/>
                {fileName}
            </p>
          </div>
        ) : (
          <div className="text-center text-gray-400">
            <UploadCloudIcon className="w-10 h-10 mx-auto mb-3" />
            <p className="font-semibold text-gray-300">
              <span className="text-cyan-400">Click to upload</span> or drag and drop
            </p>
            <p className="text-xs">CSV or TXT files</p>
          </div>
        )}
      </div>
    </div>
  );
};
