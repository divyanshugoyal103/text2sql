
import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}
  
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates an SQL query from a natural language prompt using the Gemini API.
 * @param schemaDescription A string describing the table schema.
 * @param dataPreview A preview of the data (e.g., first few CSV rows).
 * @param naturalQuery The user's query in natural language.
 * @param tableName The name of the table to query.
 * @returns A string containing the generated SQL query.
 */
export async function generateSqlFromText(
  schemaDescription: string,
  dataPreview: string,
  naturalQuery: string,
  tableName: string
): Promise<string> {
  const model = "gemini-2.5-flash-preview-04-17";

  const systemInstruction = `You are a world-class SQL generation engine. Your role is to act as an automated SQL generator for the SQLite dialect.
You will be given a table name, the schema for the table, and a preview of the data. You will also be given a question in natural language.
Your task is to generate a single, valid SQLite query that answers the question.

RULES:
- The SQL dialect must be SQLite.
- The table name will be '${tableName}'.
- Use the provided SQLite Function Reference below to construct your queries. Use functions when they are appropriate to answer the user's question.
- ONLY output the SQL query. Do NOT include any explanations, introductory text, or markdown formatting like \`\`\`sql. Your entire response must be only the raw SQL query.
- Do not add a semicolon at the end of the query.

SQLite Function Reference:
- Aggregate Functions: AVG(), COUNT(), GROUP_CONCAT(), MAX(), MIN(), SUM(), TOTAL()
- String Functions: LENGTH(), LOWER(), UPPER(), TRIM(), LTRIM(), RTRIM(), SUBSTR(), REPLACE(), INSTR()
- Math Functions: ABS(), ROUND(), RANDOM()
- Date/Time Functions: DATE(), TIME(), DATETIME(), STRFTIME(), JULIANDAY(). Use STRFTIME for complex date formatting.
- Control Flow: CASE WHEN [condition] THEN [result] ELSE [result] END
`;

  const prompt = `
Table Name: ${tableName}

Schema:
${schemaDescription}

Data Preview (first few rows):
---
${dataPreview}
---

Question: ${naturalQuery}

SQL Query:
`;

  try {
    const response = await ai.models.generateContent({
        model: model,
        contents: prompt,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0,
        },
      });
      
    const sqlQuery = response.text.trim();

    // A final check to remove markdown fences if the model accidentally adds them.
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = sqlQuery.match(fenceRegex);
    if (match && match[2]) {
      return match[2].trim();
    }
    
    return sqlQuery;

  } catch (error: unknown) {
    console.error("Error generating SQL from Gemini:", error);
    if (error instanceof Error) {
        throw new Error(`Gemini API error: ${error.message}`);
    }
    throw new Error("An unexpected error occurred while communicating with the Gemini API.");
  }
}

/**
 * Corrects an SQL query based on user feedback using the Gemini API.
 * @param schemaDescription A string describing the table schema.
 * @param tableName The name of the table to query.
 * @param originalSql The incorrect SQL query that needs fixing.
 * @param errorDescription The user's description of what's wrong with the query.
 * @returns A string containing the corrected SQL query.
 */
export async function fixGeneratedSql(
  schemaDescription: string,
  tableName: string,
  originalSql: string,
  errorDescription: string
): Promise<string> {
  const model = "gemini-2.5-flash-preview-04-17";

  const systemInstruction = `You are an expert SQL editor. Your task is to modify an existing SQL query based on a user's instruction for the SQLite dialect.
You will be provided with the table name, schema, the current SQL query, and a user's instruction.
Your goal is to produce a corrected, valid SQLite SQL query that applies the user's modification.

RULES:
- The SQL dialect must be SQLite.
- The table name is '${tableName}'.
- Use the provided SQLite Function Reference below to construct your queries. Use functions when they are appropriate to answer the user's request.
- ONLY output the modified SQL query. Do not include explanations, introductory text, or markdown formatting like \`\`\`sql. Your entire response must be only the raw, modified SQL query.
- Do not add a semicolon at the end of the query.

SQLite Function Reference:
- Aggregate Functions: AVG(), COUNT(), GROUP_CONCAT(), MAX(), MIN(), SUM(), TOTAL()
- String Functions: LENGTH(), LOWER(), UPPER(), TRIM(), LTRIM(), RTRIM(), SUBSTR(), REPLACE(), INSTR()
- Math Functions: ABS(), ROUND(), RANDOM()
- Date/Time Functions: DATE(), TIME(), DATETIME(), STRFTIME(), JULIANDAY(). Use STRFTIME for complex date formatting.
- Control Flow: CASE WHEN [condition] THEN [result] ELSE [result] END
`;

  const prompt = `
Table Name: ${tableName}

Schema:
${schemaDescription}

Current SQL Query:
${originalSql}

User's Instruction to Modify the Query:
${errorDescription}

Modified SQL Query:
`;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0,
      },
    });

    const sqlQuery = response.text.trim();

    // A final check to remove markdown fences
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = sqlQuery.match(fenceRegex);
    if (match && match[2]) {
      return match[2].trim();
    }

    return sqlQuery;
  } catch (error: unknown) {
    console.error("Error fixing SQL from Gemini:", error);
    if (error instanceof Error) {
      throw new Error(`Gemini API error while fixing SQL: ${error.message}`);
    }
    throw new Error("An unexpected error occurred while communicating with the Gemini API.");
  }
}
