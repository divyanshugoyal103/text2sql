
import React, { useState, useCallback } from 'react';
import { FileUpload } from './components/FileUpload';
import { SqlOutput } from './components/SqlOutput';
import { generateSqlFromText, fixGeneratedSql } from './services/geminiService';
import { DatabaseIcon, Wand2Icon, AlertTriangleIcon, BugIcon } from './components/Icons';

type LoadingState = 'idle' | 'generating' | 'fixing';

export default function App(): React.ReactNode {
  const [file, setFile] = useState<File | null>(null);
  const [tableName, setTableName] = useState<string>('your_table');
  const [fileContentPreview, setFileContentPreview] = useState<string>('');
  const [detectedHeaders, setDetectedHeaders] = useState<string[]>([]);
  const [naturalQuery, setNaturalQuery] = useState<string>('');
  const [generatedSql, setGeneratedSql] = useState<string>('');
  const [loadingState, setLoadingState] = useState<LoadingState>('idle');
  const [error, setError] = useState<string | null>(null);
  const [errorDescription, setErrorDescription] = useState<string>('');

  const handleFileChange = useCallback((selectedFile: File, contentPreview: string, headers: string[]): void => {
    setFile(selectedFile);
    setFileContentPreview(contentPreview);
    setDetectedHeaders(headers);

    const derivedTableName = selectedFile.name.split('.').slice(0, -1).join('.') || selectedFile.name;
    let sanitizedTableName = derivedTableName.replace(/[^a-zA-Z0-9_]/g, '_');
    if (/^\d/.test(sanitizedTableName)) {
        sanitizedTableName = `tbl_${sanitizedTableName}`;
    }
    setTableName(sanitizedTableName);

    setError(null);
  }, []);

  const handleGenerateSql = async (): Promise<void> => {
    if (!file || detectedHeaders.length === 0 || !naturalQuery) {
      setError('Please provide a file with a valid header row, and a query.');
      return;
    }

    setLoadingState('generating');
    setError(null);
    setGeneratedSql('');

    try {
      const schema = detectedHeaders.join(', ');
      const sql = await generateSqlFromText(
        schema,
        fileContentPreview,
        naturalQuery,
        tableName
      );
      setGeneratedSql(sql);
      setErrorDescription('');
    } catch (err) {
      if (err instanceof Error) {
        setError(`Failed to generate SQL: ${err.message}`);
      } else {
        setError('An unknown error occurred.');
      }
    } finally {
      setLoadingState('idle');
    }
  };
  
  const handleFixSql = async (): Promise<void> => {
    if (!generatedSql || !errorDescription) {
      setError('Please describe the error in the generated query to fix it.');
      return;
    }

    setLoadingState('fixing');
    setError(null);

    try {
      const schema = detectedHeaders.join(', ');
      const fixedSql = await fixGeneratedSql(
        schema,
        tableName,
        generatedSql,
        errorDescription
      );
      setGeneratedSql(fixedSql);
      setErrorDescription(''); // Clear the input after submission
    } catch (err) {
      if (err instanceof Error) {
        setError(`Failed to fix SQL: ${err.message}`);
      } else {
        setError('An unknown error occurred while fixing the query.');
      }
    } finally {
      setLoadingState('idle');
    }
  };

  const isGenerateButtonDisabled = !file || detectedHeaders.length === 0 || !naturalQuery || loadingState !== 'idle';
  
  const loadingText = loadingState === 'generating'
    ? 'Generating your SQL query...'
    : loadingState === 'fixing'
    ? 'Fixing your SQL query...'
    : '';

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-4xl mx-auto">
        <header className="text-center mb-10">
          <h1 className="text-4xl sm:text-5xl font-bold text-white tracking-tight">
            Text-to-SQL <span className="text-cyan-400">Generator</span>
          </h1>
          <p className="mt-4 text-lg text-gray-400">
            Upload your data file, and we'll automatically generate SQL queries from your questions.
          </p>
        </header>

        <main className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gray-800/50 p-6 rounded-2xl border border-gray-700 shadow-lg">
              <h2 className="flex items-center text-2xl font-semibold text-white mb-4">
                <span className="bg-cyan-500/10 text-cyan-400 p-2 rounded-lg mr-3">
                  <DatabaseIcon className="w-6 h-6" />
                </span>
                1. Provide Data
              </h2>
              <div className="space-y-4">
                <FileUpload onFileChange={handleFileChange} />
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Detected Columns from table: <code className="text-cyan-400 bg-gray-700 px-1 py-0.5 rounded">{tableName}</code>
                  </label>
                  <div className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 min-h-[108px] text-gray-400 flex items-center">
                    {file ? (
                      detectedHeaders.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {detectedHeaders.map((header, index) => (
                            <span key={index} className="bg-gray-700 text-cyan-300 text-xs font-medium px-2.5 py-1 rounded-full">
                              {header}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm">Could not detect headers. Please ensure your file is a CSV with a header row.</p>
                      )
                    ) : (
                      <p className="text-sm">Upload a file to see detected column headers.</p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gray-800/50 p-6 rounded-2xl border border-gray-700 shadow-lg">
              <h2 className="flex items-center text-2xl font-semibold text-white mb-4">
                <span className="bg-cyan-500/10 text-cyan-400 p-2 rounded-lg mr-3">
                  <Wand2Icon className="w-6 h-6" />
                </span>
                2. Ask a Question
              </h2>
              <div className="space-y-4">
                <div>
                  <label htmlFor="query" className="block text-sm font-medium text-gray-300 mb-2">
                    Your question in natural language
                  </label>
                  <textarea
                    id="query"
                    rows={4}
                    value={naturalQuery}
                    onChange={(e) => setNaturalQuery(e.target.value)}
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition-colors"
                    placeholder={`e.g., 'Show me all records from ${tableName} where...' or 'Find the top 5 users with the highest order amounts'`}
                  />
                </div>
                <button
                  onClick={handleGenerateSql}
                  disabled={isGenerateButtonDisabled}
                  className="w-full flex items-center justify-center bg-cyan-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-cyan-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 disabled:scale-100"
                >
                  {loadingState === 'generating' ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Generating...
                    </>
                  ) : (
                    <>
                      <Wand2Icon className="w-5 h-5 mr-2" />
                      Generate SQL
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {error && (
            <div className="bg-red-900/50 border border-red-700 text-red-300 p-4 rounded-lg flex items-center">
              <AlertTriangleIcon className="h-5 w-5 mr-3" />
              <span>{error}</span>
            </div>
          )}

          {(generatedSql || loadingState !== 'idle') && (
            <div className="mt-8">
              <SqlOutput sql={generatedSql} isLoading={loadingState !== 'idle'} loadingText={loadingText} />
            </div>
          )}
          
          {generatedSql && (loadingState === 'idle' || loadingState === 'fixing') && (
            <div className="mt-6 bg-gray-800/50 p-6 rounded-2xl border border-gray-700 shadow-lg">
              <h3 className="flex items-center text-xl font-semibold text-white mb-4">
                <BugIcon className="w-6 h-6 mr-3 text-amber-400" />
                Report an Issue & Fix Query
              </h3>
              <p className="text-sm text-gray-400 mb-4">
                If the generated query isn't quite right, describe the problem below and we'll try to fix it.
              </p>
              <div className="space-y-4">
                <div>
                  <label htmlFor="error-description" className="block text-sm font-medium text-gray-300 mb-2">
                    What's wrong with the query?
                  </label>
                  <textarea
                    id="error-description"
                    rows={3}
                    value={errorDescription}
                    onChange={(e) => setErrorDescription(e.target.value)}
                    className="w-full bg-gray-900 border border-gray-600 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition-colors"
                    placeholder="e.g., 'It should filter by users from California' or 'The join condition is incorrect'"
                  />
                </div>
                <button
                  onClick={handleFixSql}
                  disabled={!errorDescription || loadingState !== 'idle'}
                  className="w-full flex items-center justify-center bg-amber-600 text-white font-semibold py-3 px-4 rounded-lg hover:bg-amber-500 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300"
                >
                  {loadingState === 'fixing' ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Fixing...
                    </>
                  ) : (
                    <>
                      <BugIcon className="w-5 h-5 mr-2" />
                      Fix SQL Query
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
